function [nghiem, solanlap] = daycung(f, a, b, saiso)
% Hàm dùng phương pháp dây cung để tìm nghiệm của f(x) = 0
c = (a*f(b)-b*f(a)) / (f(b) - f(a));
solanlap = 0;
while abs(c - a) > saiso
if f(c)*f(a) < 0
b = c;
else
a = c;
end
% Tăng số lần lặp
solanlap = solanlap + 1;
c = (a*f(b)-b*f(a)) / (f(b) - f(a));
end
nghiem = c;
fprintf("nghiệm của phương trình: %f\n",nghiem);
fprintf("số lần lặp: %f\n",solanlap);
end