    function [nghiem, solanlap] = tieptuyen(f, a, b, saiso) %khai báo hàm tiếp tuyến
    g = diff(f); %g là đạo hàm bậc 1 của f
    h = diff(g);%h là đạo hàm bậc 2 của f
    x0 = (a + b) / 2; % Gán x0 là trung điểm của khoảng [a, b] cũng là giá trị khởi đầu cho quá trình lặp tìm nghiệm
    x1 = x0 - f(x0) / g(x0); %Tính giá trị x1 bằng công thức của phương pháp Newton-Raphson
    solanlap = 1; %khởi tạo số lần lặp bằng 1 cũng coi như lần lặp đầu
    while abs(x1 - x0) > saiso %thực hiện vòng lặp while cho đến khi abs(x1 - x0) <= saiso thì dừng
    x0 = x1;
    x1 = x0 - f(x0) / g(x0); 
    %Cập nhật x0 bằng x1 hiện tại, rồi tính x1 mới theo công thức Newton-Raphson
    solanlap = solanlap + 1; %tăng số lần lặp sau mỗi lần lặp
    end
    nghiem = x1;
    fprintf("nghiệm của phương trình: %f\n",nghiem);
    fprintf("số lần lặp: %f\n",solanlap);
    end