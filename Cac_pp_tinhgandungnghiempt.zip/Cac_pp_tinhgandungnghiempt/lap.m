function [nghiem, solanlap] = lap(fp, a, b, saiso)
x0 = a;
x1 = b;
% x0, x1 được gán là hai khoảng phân ly nghiệm
solanlap = 0;
     while abs(x1 - x0) > saiso %điều kiện chạy vòng lặp sai số tính > sai số cho phép đề cho
         x0 = x1; 
         x1 = fp(x0); 
         %cập nhật liên tục gán x0 bằng x1 hiện tại và tính x1 mới là giá trị của hàm fp tại x0
         solanlap = solanlap + 1; %số lần lặp sẽ tăng sau mỗi vòng lặp
     end
nghiem = x1; %trả về kết quả nghiệm =x1 cuối cùng
fprintf("nghiệm của phương trình: %f\n",nghiem);
fprintf("số lần lặp: %f\n",solanlap);
end %kết thúc function