function [nghiem,solanlap] = chiadoi(f,a,b,saiso) 
%tao function chiadoi voi f,a,b,saiso la cac doi so dau vao
%nghiem,solanlap la cac doi so dau ra
solanlap = 0; %thiet lap so lan lap ban dau la 0
while (b - a) > saiso %chay vong lap while voi dieu kien (b - a) > saiso
c = (a + b) / 2; 
if f(c) * f(a) < 0 
b = c; % nếu f(c)*f(a) <0 thì giá trị c gán vào b
else
a = c; % còn lại thì c sẽ được gán vào a
end
solanlap = solanlap + 1; %so lần lặp tăng sau mỗi vòng lặp
end
nghiem = a; %kết quả nghiệm trả về sẽ bằng a cuối cùng
fprintf("nghiệm của phương trình: %f\n",nghiem)
fprintf("số lần lặp: %f\n",solanlap)
end %kết thúc function